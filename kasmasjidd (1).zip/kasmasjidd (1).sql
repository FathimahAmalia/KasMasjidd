-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 24, 2026 at 03:44 AM
-- Server version: 8.0.30
-- PHP Version: 8.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasmasjidd`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `title`, `image`, `category`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'santunan anak yatim', 'activities/ggA6JNJR9Y8qtWpaxaUwrg5clGO3pZkidDAU4gon.jpg', 'Sosial', 'hari ini kita berkesempatan melakukan kegitan rutin kami setiap tahun nyaa', 1, '2026-02-05 19:00:29', '2026-02-10 18:47:25');

-- --------------------------------------------------------

--
-- Table structure for table `contact_items`
--

CREATE TABLE `contact_items` (
  `id` bigint UNSIGNED NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bi-telephone',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_items`
--

INSERT INTO `contact_items` (`id`, `label`, `value`, `icon`, `url`, `is_active`, `order`, `created_at`, `updated_at`) VALUES
(1, 'WhatsApp Admin', '+62 812-3456-7890', 'bi-whatsapp', 'https://wa.me/6281234567890', 1, 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(2, 'Email', 'info@masjid.com', 'bi-envelope', 'mailto:info@masjid.com', 1, 2, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(3, 'Lokasi', 'Lihat di Google Maps', 'bi-geo-alt', 'https://maps.google.com', 1, 3, '2026-02-12 01:56:31', '2026-02-12 01:56:31');

-- --------------------------------------------------------

--
-- Table structure for table `donasis`
--

CREATE TABLE `donasis` (
  `id` bigint UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telepon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `jenis_donasi` enum('masjid','sosial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pesan` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_donasi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `donasis`
--

INSERT INTO `donasis` (`id`, `nama`, `email`, `telepon`, `jumlah`, `jenis_donasi`, `pesan`, `status`, `payment_method`, `transaction_id`, `tanggal_donasi`, `created_at`, `updated_at`) VALUES
(1, 'hamba allah', 'hambaallah@gmail.com', NULL, 1000000.00, 'masjid', 'semoga bermaanfaat', 'pending', NULL, 'DONASI-6982ab3af1f8c', '2026-02-04 02:13:15', '2026-02-03 19:13:15', '2026-02-03 19:13:15'),
(2, 'fathimah', 'fathimah@gmail.com', NULL, 1000000.00, 'masjid', 'semoga bermaanfaat', 'pending', NULL, 'DONASI-6982b344bc8fe', '2026-02-04 02:47:32', '2026-02-03 19:47:32', '2026-02-03 19:47:32'),
(3, 'ahmad', 'ahmad@gmail.com', NULL, 200000.00, 'masjid', 'semoga bermanfaat', 'pending', NULL, 'DONASI-6982d13f1484c', '2026-02-04 04:55:27', '2026-02-03 21:55:27', '2026-02-03 21:55:27'),
(4, 'hamba allah', 'hambaallah@gmail.com', NULL, 10000.00, 'sosial', '-', 'pending', NULL, 'DONASI-6982d1c575ce6', '2026-02-04 04:57:41', '2026-02-03 21:57:41', '2026-02-03 21:57:41'),
(5, 'tasya', 'tasya@gmail.com', NULL, 10000.00, 'masjid', '-', 'pending', NULL, 'DONASI-6982d2c790552', '2026-02-04 05:01:59', '2026-02-03 22:01:59', '2026-02-03 22:01:59'),
(6, 'fathimah', 'fathimah@gmail.com', NULL, 10000.00, 'sosial', '-', 'pending', NULL, 'DONASI-6982d4b50e7cf', '2026-02-04 05:10:13', '2026-02-03 22:10:13', '2026-02-03 22:10:13'),
(7, 'yayay', 'yaya@gmail.com', NULL, 5000.00, 'masjid', '-', 'pending', NULL, 'DONASI-6982d71d58228', '2026-02-04 05:20:29', '2026-02-03 22:20:29', '2026-02-03 22:20:29'),
(8, 'hamba allah', 'hambaallah@gmail.com', NULL, 5000.00, 'masjid', '-', 'pending', NULL, 'DONASI-6982e55af3c2b', '2026-02-04 06:21:15', '2026-02-03 23:21:15', '2026-02-03 23:21:15'),
(9, 'fathimah', 'fathimahh@gmail.com', NULL, 200000.00, 'sosial', '-', 'pending', NULL, 'DONASI-6982ec8d8d96f', '2026-02-04 06:51:57', '2026-02-03 23:51:57', '2026-02-03 23:51:57'),
(10, 'hamba allah', 'hambaallah@gmail.com', NULL, 5000.00, 'masjid', '-', 'pending', NULL, 'DONASI-6982f020d2922', '2026-02-04 07:07:12', '2026-02-04 00:07:12', '2026-02-04 00:07:12');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `information_components`
--

CREATE TABLE `information_components` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('text','prayer_times','routine_activities','contact_list') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `information_components`
--

INSERT INTO `information_components` (`id`, `title`, `type`, `content`, `icon`, `order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Tentang Kami', 'text', '<div>Masjid kami berdiri sejak tahun 1990 dan terus berkembang melayani umat. Kami memiliki berbagai fasilitas mulai dari ruang sholat utama yang nyaman, perpustakaan, hingga aula serbaguna.</div>', 'bi-building', 1, 0, '2026-02-12 01:56:31', '2026-02-12 02:01:23'),
(2, 'Visi & Misi', 'text', '<ul><li><strong>Visi:</strong> Menjadi pusat peradaban Islam yang rahmatan lil alamin.</li><li><strong>Misi:</strong> Menyelenggarakan ibadah yang khusyuk, pendidikan berkualitas, dan pelayanan sosial yang amanah.</li></ul>', 'bi-bullseye', 2, 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(3, 'Jadwal Sholat', 'prayer_times', NULL, 'bi-clock', 3, 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(4, 'Kegiatan Rutin', 'routine_activities', NULL, 'bi-calendar-check', 4, 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(5, 'Hubungi Kami', 'contact_list', NULL, 'bi-telephone', 5, 0, '2026-02-12 01:56:31', '2026-02-12 02:01:23');

-- --------------------------------------------------------

--
-- Table structure for table `landing_settings`
--

CREATE TABLE `landing_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `landing_settings`
--

INSERT INTO `landing_settings` (`id`, `key`, `value`, `type`, `label`, `created_at`, `updated_at`) VALUES
(1, 'hero_title', 'Wujudkan Amal Jariyah Bersama Masjid Nabawi', 'text', 'Judul Hero', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(2, 'hero_description', 'Platform digital pengelolaan keuangan masjid yang transparan. Salurkan donasi Anda dengan mudah, aman, dan barokah untuk kemaslahatan umat.', 'textarea', 'Deskripsi Hero', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(3, 'about_title', 'Mengelola dengan Amanah', 'text', 'Judul Tentang Kami', '2026-02-05 18:53:13', '2026-02-05 19:21:51'),
(4, 'about_description', 'Masjid Nabawi hadir dengan sistem manajemen keuangan digital', 'textarea', 'Deskripsi Tentang Kami', '2026-02-05 18:53:13', '2026-02-05 19:21:51'),
(5, 'about_image', 'settings/BArDdC6nrpQYgOwIFIoIr9Hle4FeZXMLC0wOKqbi.jpg', 'image', 'Gambar Tentang Kami', '2026-02-05 18:53:13', '2026-02-11 19:52:54'),
(6, 'contact_address', 'Jl. Masjid Nabawi No. 123, Komplek Surga Firdaus, Kota Madani, Indonesia', 'text', 'Alamat', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(7, 'contact_phone', '+62 812-3456-7890', 'text', 'Nomor Telepon', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(8, 'contact_email', 'info@masjidnabawi.com', 'text', 'Email', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(9, 'social_facebook', '#', 'text', 'Link Facebook', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(10, 'social_instagram', '#', 'text', 'Link Instagram', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(11, 'social_youtube', '#', 'text', 'Link Youtube', '2026-02-05 18:53:13', '2026-02-05 18:53:13'),
(12, 'profile_description', 'Masjid ini didirikan dengan tujuan untuk memfasilitasi ibadah umat Islam serta menjadi pusat kegiatan sosial dan pendidikan bagi masyarakat sekitar. Kami berkomitmen untuk memberikan pelayanan terbaik bagi jamaah.', 'textarea', 'Deskripsi Profil Lengkap', '2026-02-05 19:15:02', '2026-02-12 01:56:31'),
(13, 'prayer_subuh', '04:30', 'text', 'Jadwal Subuh', '2026-02-05 19:15:02', '2026-02-05 19:15:02'),
(14, 'prayer_dzuhur', '12:00', 'text', 'Jadwal Dzuhur', '2026-02-05 19:15:02', '2026-02-05 19:15:02'),
(15, 'prayer_ashar', '15:15', 'text', 'Jadwal Ashar', '2026-02-05 19:15:02', '2026-02-05 19:15:02'),
(16, 'prayer_maghrib', '18:00', 'text', 'Jadwal Maghrib', '2026-02-05 19:15:02', '2026-02-12 01:56:31'),
(17, 'prayer_isya', '19:15', 'text', 'Jadwal Isya', '2026-02-05 19:15:02', '2026-02-12 01:56:31'),
(18, 'contact_google_maps_link', 'https://maps.google.com', 'text', 'Link Google Maps', '2026-02-05 19:19:26', '2026-02-05 19:19:26'),
(19, 'nama_masjid', 'masjid al taqwa', 'text', 'Nama Masjid', '2026-02-11 18:41:08', '2026-02-18 02:51:45'),
(20, 'info_page_title', 'Informasi Masjid', 'text', NULL, '2026-02-12 01:52:30', '2026-02-12 01:52:30'),
(21, 'info_page_subtitle', 'Pusat informasi kegiatan, jadwal, dan layanan untuk jamaah.', 'text', NULL, '2026-02-12 01:52:30', '2026-02-12 01:56:31'),
(22, 'prayer_jumat', '11:45', 'text', NULL, '2026-02-12 01:52:30', '2026-02-12 01:56:31'),
(23, 'visi_misi_content', 'Menjadikan masjid sebagai pusat ibadah, pendidikan, dan pemberdayaan umat yang amanah, transparan, dan bermanfaat bagi masyarakat\r\n\r\nMeningkatkan kualitas ibadah melalui pelaksanaan shalat berjamaah, kajian rutin, dan kegiatan keagamaan lainnya.\r\n\r\nMenyelenggarakan pendidikan Islam seperti TPA, kajian remaja, dan pelatihan keislaman.\r\n\r\nMengelola keuangan masjid secara transparan dan profesional melalui sistem pencatatan kas yang tertib.\r\n\r\nMeningkatkan kegiatan sosial seperti santunan, bakti sosial, dan bantuan untuk masyarakat sekitar.', 'text', NULL, '2026-02-12 21:02:46', '2026-02-12 21:02:46'),
(24, 'vision', 'Menjadikan masjid sebagai pusat ibadah, pendidikan, dan pemberdayaan umat yang amanah, transparan, dan bermanfaat bagi masyarakat', 'text', NULL, '2026-02-12 21:12:16', '2026-02-12 21:12:16'),
(25, 'mission', 'Meningkatkan kualitas ibadah melalui pelaksanaan shalat berjamaah, kajian rutin, dan kegiatan keagamaan lainnya.\r\n\r\nMenyelenggarakan pendidikan Islam seperti TPA, kajian remaja, dan pelatihan keislaman.\r\n\r\nMengelola keuangan masjid secara transparan dan profesional melalui sistem pencatatan kas yang tertib.\r\n\r\nMeningkatkan kegiatan sosial seperti santunan, bakti sosial, dan bantuan untuk masyarakat sekitar.', 'text', NULL, '2026-02-12 21:12:16', '2026-02-12 21:12:16');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2026_01_20_090223_create_roles_table', 1),
(7, '2026_01_20_090637_create_role_user_table', 1),
(8, '2026_01_26_030207_create_pemasukan_masjid_table', 1),
(9, '2026_01_26_031125_rename_jumlah_to_nominal_in_pemasukan_masjid', 1),
(10, '2026_01_26_044227_create_pengeluaran_masjids_table', 1),
(11, '2026_01_26_065214_create_rekap_kas_table', 1),
(12, '2026_01_26_085859_create_pemasukan_sosials_table', 1),
(13, '2026_01_26_093023_create_pengeluaran_sosials_table', 1),
(14, '2026_01_27_080821_create_rekap_kas_sosials_table', 1),
(15, '2026_01_29_100000_add_profile_picture_to_users_table', 1),
(16, '2026_01_30_033915_create_donasis_table', 2),
(17, '2026_02_06_014840_create_activities_table', 3),
(18, '2026_02_06_015023_create_landing_settings_table', 3),
(19, '2026_02_12_062053_create_routine_activities_table', 4),
(20, '2026_02_12_065029_create_information_components_table', 5),
(21, '2026_02_12_065157_create_contact_items_table', 5),
(22, '2026_02_12_080125_add_image_to_information_components_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pemasukan_masjids`
--

CREATE TABLE `pemasukan_masjids` (
  `id` bigint UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `sumber_dana` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nominal` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pemasukan_masjids`
--

INSERT INTO `pemasukan_masjids` (`id`, `tanggal`, `sumber_dana`, `keterangan`, `nominal`, `created_at`, `updated_at`) VALUES
(7, '2026-02-23', 'Donatur', '-', 100000.00, '2026-02-22 21:38:04', '2026-02-22 21:38:04');

-- --------------------------------------------------------

--
-- Table structure for table `pemasukan_sosials`
--

CREATE TABLE `pemasukan_sosials` (
  `id` bigint UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `sumber_dana` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `jumlah` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pemasukan_sosials`
--

INSERT INTO `pemasukan_sosials` (`id`, `tanggal`, `sumber_dana`, `keterangan`, `jumlah`, `created_at`, `updated_at`) VALUES
(2, '2026-01-30', 'infak jumat', '-', 100000, '2026-01-29 19:24:53', '2026-01-29 19:24:53'),
(3, '2026-02-06', 'lain', '-', 100000, '2026-02-05 19:59:24', '2026-02-05 19:59:24');

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_masjids`
--

CREATE TABLE `pengeluaran_masjids` (
  `id` bigint UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `jenis_pengeluaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` bigint NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengeluaran_masjids`
--

INSERT INTO `pengeluaran_masjids` (`id`, `tanggal`, `jenis_pengeluaran`, `nominal`, `keterangan`, `created_at`, `updated_at`) VALUES
(11, '2026-02-23', 'lain lain', 20000, '-', '2026-02-22 21:38:18', '2026-02-22 21:38:18');

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran_sosials`
--

CREATE TABLE `pengeluaran_sosials` (
  `id` bigint UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `jenis_pengeluaran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` bigint NOT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengeluaran_sosials`
--

INSERT INTO `pengeluaran_sosials` (`id`, `tanggal`, `jenis_pengeluaran`, `nominal`, `keterangan`, `created_at`, `updated_at`) VALUES
(3, '2026-01-30', 'sumbangan', 20000, '-', '2026-01-29 19:25:10', '2026-01-29 19:25:10'),
(4, '2026-02-06', 'lain lain', 50000, '-', '2026-02-05 20:04:16', '2026-02-05 20:04:16');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rekap_kas`
--

CREATE TABLE `rekap_kas` (
  `id` bigint UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `total_pemasukan` bigint NOT NULL DEFAULT '0',
  `total_pengeluaran` bigint NOT NULL DEFAULT '0',
  `saldo` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rekap_kas_sosials`
--

CREATE TABLE `rekap_kas_sosials` (
  `id` bigint UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `total_pemasukan` bigint NOT NULL DEFAULT '0',
  `total_pengeluaran` bigint NOT NULL DEFAULT '0',
  `saldo` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2026-01-28 20:39:49', '2026-01-28 20:39:49'),
(2, 'bendahara', '2026-01-28 20:39:49', '2026-01-28 20:39:49'),
(3, 'pengguna', '2026-01-28 20:39:49', '2026-01-28 20:39:49');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 2, NULL, NULL),
(3, 3, 3, NULL, NULL),
(4, 4, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `routine_activities`
--

CREATE TABLE `routine_activities` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bi-check-circle',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `routine_activities`
--

INSERT INTO `routine_activities` (`id`, `name`, `description`, `icon`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Kajian Rutin Ahad Pagi', 'Setiap hari Ahad pukul 06.00 WIB bersama Ustadz Fulan.', 'bi-book', 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(2, 'Taman Pendidikan Al-Quran', 'Senin - Jumat pukul 16.00 WIB untuk anak-anak.', 'bi-people', 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31'),
(3, 'Jumat Berkah', 'Pembagian nasi bungkus setiap hari Jumat setelah sholat Jumat.', 'bi-gift', 1, '2026-02-12 01:56:31', '2026-02-12 01:56:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `profile_picture`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin Masjid', 'admin@gmail.com', NULL, '$2y$10$jeNuG7gBJ31G8/4ihxxr1uM7YSdk/E0BCzciZwyjQD/W5.GiFxNUu', 'profile-pictures/EUmK6ADD3TZlY6Cj6lVQwibA4ovsSBWYYauH1dF0.jpg', NULL, '2026-01-28 20:39:50', '2026-01-29 00:21:46'),
(2, 'Bendahara Masjid', 'bendahara@gmail.com', NULL, '$2y$10$Ud7H3vKooQePjITbX5sBmOtDcO3/MxutuWK9UUAlRsJ3/qls2QxgO', NULL, NULL, '2026-01-28 20:39:50', '2026-01-28 20:39:50'),
(3, 'Pengguna Biasa', 'pengguna@gmail.com', NULL, '$2y$10$0YDhZm2JeAId.JjlrcNvEuZcJFcO6tWVcK3rcDF1MD5nSMu2qBF6S', NULL, NULL, '2026-01-28 20:39:50', '2026-01-28 20:39:50'),
(4, 'fathimah', 'fathimah@gmail.com', NULL, '$2y$10$s6TWFRlLEDPBN9enDeR6aelFT8xu5FK0tJuLF/5g8TGOM7RuUqpMC', 'profile-pictures/blFzVdaP1xz6Loq3l6UfLm12lxJ9yMPyifurtIn6.jpg', NULL, '2026-01-29 21:18:05', '2026-01-29 21:19:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_items`
--
ALTER TABLE `contact_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donasis`
--
ALTER TABLE `donasis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `information_components`
--
ALTER TABLE `information_components`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landing_settings`
--
ALTER TABLE `landing_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `landing_settings_key_unique` (`key`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `pemasukan_masjids`
--
ALTER TABLE `pemasukan_masjids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemasukan_sosials`
--
ALTER TABLE `pemasukan_sosials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengeluaran_masjids`
--
ALTER TABLE `pengeluaran_masjids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengeluaran_sosials`
--
ALTER TABLE `pengeluaran_sosials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `rekap_kas`
--
ALTER TABLE `rekap_kas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rekap_kas_sosials`
--
ALTER TABLE `rekap_kas_sosials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `routine_activities`
--
ALTER TABLE `routine_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_items`
--
ALTER TABLE `contact_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donasis`
--
ALTER TABLE `donasis`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `information_components`
--
ALTER TABLE `information_components`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `landing_settings`
--
ALTER TABLE `landing_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `pemasukan_masjids`
--
ALTER TABLE `pemasukan_masjids`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pemasukan_sosials`
--
ALTER TABLE `pemasukan_sosials`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pengeluaran_masjids`
--
ALTER TABLE `pengeluaran_masjids`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pengeluaran_sosials`
--
ALTER TABLE `pengeluaran_sosials`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rekap_kas`
--
ALTER TABLE `rekap_kas`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rekap_kas_sosials`
--
ALTER TABLE `rekap_kas_sosials`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `routine_activities`
--
ALTER TABLE `routine_activities`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
